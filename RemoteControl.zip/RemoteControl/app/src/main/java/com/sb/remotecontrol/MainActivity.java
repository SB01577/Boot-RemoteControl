package com.sb.remotecontrol;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    // Declare the TextView variable
    private static TextView myTextView;
    private static EditText ipAddressInput;
    private static TextView myTextView2;
    private static ScrollView myScrollView;

    //angles of the smartphone. values are set in MainActivity.onSensorChanged. they are used by Tx.createdata
    public static byte angleX;
    public static byte angleY;

    // link status variables



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

                //register acceleration sensor
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        // unkonwn effects
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // initialize text Widow for IP address
        ipAddressInput = findViewById(R.id.ipAddressInput);

        // Initialize the TextView
        myTextView = findViewById(R.id.myTextView);
        myTextView2 = findViewById(R.id.myTextView2);
        myScrollView = findViewById(R.id.myScrollView);
        // Set the text using a method
        //setTextInDebugWindow("Main Activity OnCreate finished");


    }
    // acceleration sensor handling
    @Override
    protected void onResume() {
        super.onResume();
        // Register the listener for accelerometer updates
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }
    // acceleration sensor handling
    @Override
    protected void onPause() {
        super.onPause();
        // Unregister the listener to save battery
        sensorManager.unregisterListener(this);
    }

    //acceleration sensot
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0]; // Acceleration in x-axis
            float y = event.values[1]; // Acceleration in y-axis
            float z = event.values[2]; // Acceleration in z-axis

            /*
            // Calculate tilt in degrees
            double tiltX = Math.toDegrees(Math.atan2(y, Math.sqrt(x * x + z * z)));
            double tiltY = Math.toDegrees(Math.atan2(x, Math.sqrt(y * y + z * z)));
            */
            // Calculate tilt in degrees
            double tiltZ = Math.toDegrees(Math.atan2(y, x)); // Tilt around Z-axis

            // Convert tiltZ to a byte value, limiting the range to -127 to 127
            angleX = (byte) Math.round(tiltZ); // Round to the nearest integer
            if (angleX > 127) {
                angleX = 127; // Cap at 127
            } else if (angleX < -127) {
                angleX = -127; // Cap at -127
            }
            //angleX =  (byte) Math.toDegrees(Math.atan2(y, x)); // This is the tilt around Z-axis
            angleY =  (byte) Math.toDegrees(Math.atan2(x, z)); // This is not the tilt around Y-axis


            setTextInDebugWindow("AngleX: "+ angleX + " AngleY: "+ angleY );
            myTextView2.setText(" LinkLocked: "+ Tx.handshakeDone + " .current package loss: "+LinkQuality.countPackageLosses()+ " .total lost packages: "+LinkQuality.countPackageLosses2()+" .ping: "+LinkQuality.calcAvgTrvlTme());

        }
    }
    //acceleration sensor handling
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used in this example
    }


    // Method to set text in the TextView
    public static void setTextInDebugWindow(String text) {
        /*
        // Get the current text and append new text
        String currentText = myTextView.getText().toString();
        myTextView.setText(currentText + "\n" + text);
        */
        myTextView.setText(text);

        /*
        // Scroll to the bottom
        myScrollView.post(new Runnable() {
            @Override
            public void run() {
                myScrollView.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
        */

    }

    public void setAngle(View view)
    {
        Log.d("main activity", "setAngle started");
        Tx.setZeroAngle(angleY);
        Log.d(String.valueOf(angleY), String.valueOf(angleY));
    }

    public void main(View view) //triggered by the buttonLinkInit (oben b1)
    {
        Log.d("main activity", "Main Activity main started");
        // setTextInDebugWindow("Main Activity main started");
        // definition of arguments for the main methods
        // string(0) = cycle time for CarFeedback
        // string(1) = cycle time for DrvInputs
        // string(2) = cycle time for Tx
        // string(3) = cycle time for Rx
        // string(4) = cycle time for RCGUI
        //use prime number so they rarely run all together
        String[] initArguments = {"809", "827", "1010", "1009", "1013"};

		/* initiate all objects. correct order is
		1. GUI before Tx as the GUI will later allow to set the Internet addresses
		2. Rx after Tx as Tx initiates 3 way handshake
		*/
        //CarFeedback.main(initArguments);
        //DrvInputs.main(initArguments);
        //RCGUI.main(initArguments);

        Tx.main(initArguments);
        Rx.main(initArguments);
        // setTextInDebugWindow("Main Activity main finished");

        //hand over IP address
        Tx.setInetAddressVehicle(ipAddressInput.getText().toString().trim());


    }


}