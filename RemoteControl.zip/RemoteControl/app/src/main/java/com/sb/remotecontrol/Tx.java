

package com.sb.remotecontrol;
// Laptop A (Sender)
import android.util.Log;
import androidx.core.content.ContextCompat;

import java.net.*;
import java.io.*;


public class Tx extends Thread {
    static byte[] data = new byte[10]; //zyklisch ausgetauschte Daten
    static byte zeroAngle=60; //angleY at which the egnine is neither accelerated nor braked. will be set via method from MinActivity
    static int time; //Frequenz mit der der Thread läuft, d.h. die Daten gesendet werden
    //static InetAddress IPAddressRC; //IP address of the remote control Sender / Smartphone DESKTOP-AMTFGKU 192.168.178.72
    static InetAddress IPAddressVehicle; //wird gesetzt in setInetAddressVehicle
    static int receiverPort;//wird gesetzt in setInetAddressVehicle
    //IPAddressVehicle = "192.168.178.31"; //receivers address
    //IPAddressRC = "192.168.178.72"; //senders address
    static byte frameCounter; // identifying each frame with a rolling number
    public static boolean handshakeDone; //turns to true after 3 way handshake was executed in thread

    public static void setZeroAngle(byte a) {
        zeroAngle=a;
    }


    public void run() {
      while(true) {
          System.out.println("Tx run: first line");
          System.out.println(time);
          System.out.println(handshakeDone);
          //if handshakeDone is true (i.e. linkinit was performed succesfully) then transmit data. otherwise to handshake
          if (handshakeDone) {
              System.out.println("Tx run: handshake true 1");
              // den SOCKET closen am Ende mit FINALLY !!!!!
              DatagramSocket socket = null;  // Sender's port will be assigned by the system
              try {
                  socket = new DatagramSocket();  // Sender's port will be assigned by the system
                  DatagramPacket packet = new DatagramPacket(data, data.length, IPAddressVehicle, receiverPort);
                  while (true) {
                      createData(); // fills the byte array data[10] with fresh data
                      socket.send(packet);
                      LinkQuality.startMeasurement(data[7]);
                      System.out.println("data transimmted");
                      Thread.sleep(time);  // Delay for given amount of milliseconds
                  }
              } catch (SocketException e) {
                  // Handle SocketException
                  e.printStackTrace();
              } catch (UnknownHostException e) {
                  // Handle UnknownHostException
                  e.printStackTrace();
              } catch (IOException e) {
                  // Handle IOException
                  e.printStackTrace();
              } catch (InterruptedException e) {
                  // Handle InterruptedException
                  e.printStackTrace();
              } finally {
                  if (socket != null) {
                      socket.close();
                  }
              }
          } else {
              // 3 way handshake was not done yet
              System.out.println("TX initLink starting now");
              //MainActivity.setTextInDebugWindow("Tx run: starting InitLink");
              initLink();
              //handshakeDone=true; //Ersatzfunktion
              System.out.println("Tx.run: initLink was executed");
              System.out.println(handshakeDone);
              System.out.println(time);
              //MainActivity.setTextInDebugWindow("Tx run: InitLink finished");
          }

          try {
              Thread.sleep(time); // Pausing for 100 milliseconds

          } catch (InterruptedException e) {
              // Handle the exception if needed
              e.printStackTrace();
          }
      }
    }

    public static byte getFrameCounter() {
        return frameCounter;
    }

    private static void createData() {
        // fills the byte array data[10] with fresh data
        //data [0] = metadata
        // 0 = normal mode, i.e. remote control sending to vehicle
        // 1 = response mode, i.e. vehicle sending to remote control
        data[0]=0;

        //data [1] = diagnostics
        // 255 = battery_1 low on vehicle
        // 254 = battery_2 low on vehicle
        // 253 = network connection weak
        // 0 = fine
        data[1]=0;

        //data [2] = steering
        data[2] = MainActivity.angleX; //REMOVE DrvInputs.getSteering();
        //System.out.println("content of transmitted data (sailing only)");
        //System.out.println(data[2]);

        //data [3] = acceleration
        data[3] = MainActivity.angleY; //REMOVE DrvInputs.getAcceleration();

        //data [4] = sail
        data[4] = 2; //REMOVE DrvInputs.getSail();

        //data [5] = trimming (moving a weight starboard / portside)
        data[5]=0;

        //data [6] = sailing command (command for tack or jib)
        data[6]=0;

        //data [7]
        switch (frameCounter) {
            case 127:
                frameCounter = -128;
                break;
            default:
                frameCounter++;
        }
        data[7]=frameCounter;

        //data [8] = defines the 'zero angle' at which the engine should be idle
        data[8]=zeroAngle;

        //data [9] = FEC data
        data[9]=0;

        System.out.println(data[0]+" "+data[1]+" "+data[2]+" "+data[3]+" "+data[4]+ " "+ data[5]+" "+data[6] + " "+data[7]+ " "+data[8] + " "+data[9]);
    }



    public static void main(String[] args) {
        System.out.println("Tx main reached");
        //MainActivity.setTextInDebugWindow("Tx main started");
        // set port and Vehicle IP address

        //removed because it gets the info from MainActivity
        //setInetAddressVehicle();
        handshakeDone=false;
        frameCounter = 0;
        time = Integer.parseInt(args[2]);
        Tx thread = new Tx();
        //MainActivity.setTextInDebugWindow("Tx main: Internet addresse sset, framecounter initialiszed, thread starting now");
        thread.start();

    }

    public static int getReceveirPort() {
        return receiverPort;
    }

    public static void setInetAddressVehicle( String a) {

        //EINFÜGEN: argumente mit IP address & port können übergeben werden

        receiverPort = 50000;

        try {
            //IPAddressVehicle= InetAddress.getByName("192.168.178.96");

            // to get value from text field
            IPAddressVehicle = InetAddress.getByName(a);
            System.out.println("Tx setInetAddressVehicle string a = "+ a);
            //letzter statischer wert:
            //IPAddressVehicle= InetAddress.getByName("192.168.178.90");
            //IPAddressVehicle= InetAddress.getByName("192.168.178.31"); //Hometown value of red laptop
            // 192.168.178.90 raspi in lippstadt
            // address of Raspi in Samsung network: 192.168.4.98
            // address in lippstadt home network of red laptop: "192.168.178.31");
            //IPAddressVehicle= InetAddress.getByName("192.168.0.140");
        } catch (UnknownHostException e) {
            // Handle the UnknownHostException
            System.err.println("Tcx setInetAddressVehicle Unknown host: " + e.getMessage());
        }
        System.out.println("Tx setInetAddressVehicle successful");
    }


    private static void initLink() {

        DatagramSocket socket1 = null;  // Sender's port will be assigned by the system
        //System.out.println("Tx initLink 1");
        //MainActivity.setTextInDebugWindow("Tx initLink 1");

        try {
            socket1 = new DatagramSocket(receiverPort);  // Sender's port will be assigned by the system
            //System.out.println("Tx initLink 2");
            //MainActivity.setTextInDebugWindow("Tx initLink 2");
            //int receiverPort = 50000;  // Receiver's port

            // send SYN
            byte[] syn = "SYN".getBytes();  // Assuming IPAddressRC is a String
            DatagramPacket packetSyn = new DatagramPacket(syn, syn.length, IPAddressVehicle, receiverPort);
            //System.out.println("Tx initLink 3");
            //MainActivity.setTextInDebugWindow("Tx initLink 3");
            socket1.send(packetSyn);
            //System.out.println("Tx initLink 4");
            //MainActivity.setTextInDebugWindow("Tx initLink 4");

            // receive SYN-ACK
            byte[] synACK = new byte[7];
            DatagramPacket packetSynAck = new DatagramPacket(synACK, synACK.length);
            //System.out.println("Tx initLink 5");
            //MainActivity.setTextInDebugWindow("Tx initLink 5");
            socket1.receive(packetSynAck);
            //System.out.println("Tx initLink 6");
            //MainActivity.setTextInDebugWindow("Tx initLink 6");

            //check SYN-ACK for content "SYN-ACK". Vehicle is sending exactly that string
            byte empfang[] = packetSynAck.getData();
            //System.out.println("Tx initLink 7");
            //MainActivity.setTextInDebugWindow("Tx initLink 7");
            String bla = new String(empfang, 0, packetSynAck.getLength());
            if (bla.equals("SYN-ACK")) {
                // send "ACK"
                byte[] ack = "ACK".getBytes();  // Assuming IPAddressRC is a String
                DatagramPacket packetAck = new DatagramPacket(ack, ack.length, IPAddressVehicle, receiverPort);
                socket1.send(packetAck);
                handshakeDone=true;
                System.out.println("Tx.linkinit: Link successful");
                //MainActivity.setTextInDebugWindow("Tx thread linkinit successful");
                //wait 100 ms for Vehicle to switch to normal mode

                /*
                try {
                    Thread.sleep(100); // Pausing for 100 milliseconds
                } catch (InterruptedException e) {
                    // Handle the exception if needed
                    e.printStackTrace();
                }
                */


            }
            else {
                handshakeDone=false;
                System.out.println("Tx thread linkinit failed");
                //MainActivity.setTextInDebugWindow("Tx thread linkinit failed");
            }


        } catch (SocketException e) {
            // Handle SocketException
            e.printStackTrace();
            MainActivity.setTextInDebugWindow(e.getMessage());
        } catch (UnknownHostException e) {
            // Handle UnknownHostException
            e.printStackTrace();
            MainActivity.setTextInDebugWindow(e.getMessage());
        } catch (IOException e) {
            // Handle IOException
            e.printStackTrace();
            MainActivity.setTextInDebugWindow(e.getMessage());
        } finally {
            if (socket1 != null) {
                socket1.close();
            }
        }
        //return false;
    }
}