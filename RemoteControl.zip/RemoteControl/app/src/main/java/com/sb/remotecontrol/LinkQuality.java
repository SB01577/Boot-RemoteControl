package com.sb.remotecontrol;

public class LinkQuality {
    /*the methods here are called by Tx and Rx.
     */
    private static long data[][] = new long[10][4];
    /*explanation of data array
     * 1st dimension is row indicator: each row is for a package that has been sent
     * 2nd dimension:
     * - 0: contains frameID
     * - 1 contains status:
             0: timer is not used
             1: timer is running
             2: package was not received within the last 5 frames, i.e. it was lost
     * - 2: contains startTime of the frame
     * - 3: contains travel time of that package
     */
    private static byte i; //row identifier in the matrix (counting from 0 to 9)

    private static int losses2; //count total losses, is never set back to zero

    public static void stopMeasurement(byte frameID) {
        //find out in which row of data[?] the frameID is and measure their time
        for (byte x = 0; x < 10; x++) {
            if (data[x][0] == frameID) {
                data[x][1] = 0; //mark timer as stopped. this helps to identify a package loss
                Long TravelTime;
                TravelTime = System.currentTimeMillis() - (data[x][2]);
                data[x][3] = TravelTime;

            }
        }
        System.out.println("LinkQuality stopMeasurement frame: "+frameID);
        System.out.println("data [0]: "+data[0][0] + " "+data[0][1]+ " "+data[0][2]+ " "+data[0][3]);
        System.out.println("data [1]: "+data[1][0] + " "+data[1][1]+ " "+data[1][2]+ " "+data[1][3]);
        System.out.println("data [2]: "+data[2][0] + " "+data[2][1]+ " "+data[2][2]+ " "+data[2][3]);
        System.out.println("data [3]: "+data[3][0] + " "+data[3][1]+ " "+data[3][2]+ " "+data[3][3]);
        System.out.println("data [4]: "+data[4][0] + " "+data[4][1]+ " "+data[4][2]+ " "+data[4][3]);
        System.out.println("data [5]: "+data[5][0] + " "+data[5][1]+ " "+data[5][2]+ " "+data[5][3]);
        System.out.println("data [6]: "+data[0][0] + " "+data[0][1]+ " "+data[0][2]+ " "+data[0][3]);
        System.out.println("data [7]: "+data[0][0] + " "+data[0][1]+ " "+data[0][2]+ " "+data[0][3]);
        System.out.println("data [8]: "+data[0][0] + " "+data[0][1]+ " "+data[0][2]+ " "+data[0][3]);
        System.out.println("data [9]: "+data[0][0] + " "+data[0][1]+ " "+data[0][2]+ " "+data[0][3]);



    }
    public static int calcAvgTrvlTme(){
        long a=0;
        byte b=0;
        for (byte x = 0; x < 10; x++) {
            if (data[x][1]==0) {
                b++;
                a = a + data[x][3];
            }

        }
        a=a/b;
        System.out.println("LinkQuality calc AvgTrvlTme: "+a);
        return (byte) a;
    }

    public static int countPackageLosses2() {

        for (byte x = 0; x < 10; x++) {
            if (data[i][1]==2) {
                losses2++;
            }
        }
        return losses2;
    }

    public static byte countPackageLosses() {
        byte losses=0; // counts lost packages. set to zero before starting count
        for (byte x = 0; x < 10; x++) {
            if (data[i][1]==2) {
                losses++;
            }
        }
        return losses;
    }

    public static void startMeasurement(byte frameID) {
        data[i][0] = frameID; //write frame-ID in current row and column 0 of the table
        data[i][2] = System.currentTimeMillis(); //note the start-time
        System.out.println("LinkQuality startMeasurement frame: "+frameID);
        switch ((short) data[i][1]) { // meaning see below short block
            case 2:
                data[i][1] = 1;
                break;
            case 1:
                data[i][1] = 2; // in this case the timer for this row is still running when the next package is used in that row. 2 indicates this case
                break;
            case 0:
                data[i][1] = 1;
                break;


        }

        /*meaning of column 1:
         * 0: timer is not used
         * 1: timer is running
         * 2: package was not received within the last 5 frames, i.e. it was lost
         */

        // i is a private variable of thi s class
        i++; // increment i and set back to 0 if out of bounds
        if (i == 10) {
            i = 0;
        }
    }

}

