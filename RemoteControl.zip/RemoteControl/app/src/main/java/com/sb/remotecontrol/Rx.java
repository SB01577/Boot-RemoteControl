package com.sb.remotecontrol;

import java.net.*;
import java.io.IOException;


public class Rx extends Thread {
    static int time; //cycle time of the thread
    static byte data[] = new byte[10]; //received byte array
    static short ping[] = new short[5]; //array containing the 5 last ping times, i.e. the travel time of a UDP package between vehicle and RC
    static byte packageLoss; //counts the number of UDP packages not ackknowledged by vehicle in a row

    public void run() {
      while (true) {
          DatagramSocket socket = null;
          //System.out.println("Rx port numebr is: "+Tx.getReceveirPort()+1);
          try {
              socket = new DatagramSocket(Tx.getReceveirPort() + 1);  // Receiver's port here is the other port used + 1
              System.out.println("Rx port numebr is: " + Tx.getReceveirPort() + 1);
              byte[] buffer = new byte[10];  // Sufficient buffer size
              DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

              //while (true) {
              socket.receive(packet);
              System.arraycopy(packet.getData(), 0, data, 0, 10);
              interpretData();
              Thread.sleep(time);
              //}
          } catch (SocketException e) {
              // Handle SocketException
              e.printStackTrace();
              MainActivity.setTextInDebugWindow(e.getMessage());
          } catch (IOException e) {
              // Handle IOException
              e.printStackTrace();
              MainActivity.setTextInDebugWindow(e.getMessage());
          } catch (InterruptedException e) {
              e.printStackTrace();
              MainActivity.setTextInDebugWindow(e.getMessage());

          } finally {
              if (socket != null) {
                  socket.close();
              }
          }
      }
    }


    static void interpretData() {
        // first stop the runtime measurement for the current package / frame
        String PacketRuntime;
        //PacketRuntime=String.valueOf(LinkQuality.stopMeasurement(data[0]));
        //MainActivity.setTextInDebugWindow(PacketRuntime);        //measure the packet runtime of frame data[0]
        LinkQuality.stopMeasurement(data[0]);

        System.out.println("Rx. interpretdata. letztergesendeter frame ist: "+ Tx.getFrameCounter());
        System.out.println("Rx. interpretdata. letzter bestätigter frame ist: "+data[0]);


    }

    public static void main(String[] args) {

        time = Integer.parseInt(args[3]);
        Rx thread = new Rx();
        thread.start();

    }
}