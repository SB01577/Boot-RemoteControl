import java.io.IOException;
import java.net.*;

public class Tx extends Thread {
	static byte[] data = new byte[10]; //received data in known format
	static int time;	
	static InetAddress IPAddressRC; // address of RC. This module here is vehicle
	static int receiverPort; //is set in main function of Tx
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//precondition: Rx thread is running and connection to vehicle already established
		
		//get vehicles address from Tx module
		IPAddressRC=Rx.provideRCAddress();
		receiverPort=50001; //needs to be set to the other receivers port + 1
		System.out.println("Tx. RC has"+IPAddressRC);
		
		//init Tx thread
		time = Integer.parseInt(args[0]);
		Tx thread = new Tx();
		thread.start();
		
	}

	private static void createData() {
		// return the latest frame ID received
		data[0] = Rx.getLatestFrame();
		
		
		data[1] = 0;
		
		
		data[2] = 0;
		
		
		data[3] = 0;
		
		
		data[4] = 0;
		
		
		data[5] = 0;
		
		
		data[6] = 0;
		
		
		data[7] = 0;
		
		
		data[8] = 0;
		
		
		data[9] = 0;
	}
	
	
	public void run() {
		DatagramSocket socket = null;
		try {
			socket = new DatagramSocket();
			DatagramPacket packet = new DatagramPacket(data, data.length, IPAddressRC, receiverPort);
			
			while (true) {
				createData(); //create data to be sent
				socket.send(packet);
				Thread.sleep(time); //time is set in main funciton of Tx module
			}
			
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			if (socket != null) {
				socket.close();
			}
		}
	
	}
		
	
}
