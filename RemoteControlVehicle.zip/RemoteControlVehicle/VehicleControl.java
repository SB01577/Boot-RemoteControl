
/* SW designed to control a Raspberry Pi 2 Model B v1.1 from 2014
 GPIO pin usage:
 	- motor1
 		- gpio26 (PMW0)
 		- GND gpio14
 	- motor2
 		- gpio23 (PWM1)
 		- GND  gpio20
*/
import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.PinState;
import com.pi4j.io.gpio.Pin;
import com.pi4j.io.gpio.GpioPinPwmOutput;
import com.pi4j.io.gpio.RaspiPin;

import com.pi4j.io.gpio.RaspiGpioProvider;
//import com.pi4j.io.gpio.PinNumberingScheme;
// switch to raspbery pi home directory and insert:
// sudo /usr/lib/jvm/jre-21.0.7-full/bin/java -cp "RCV.jar:pi4j-core.jar:jaxb-api.jar:junit.jar:pi4j-core-javadoc.jar:pi4j-core-sources.jar" VehicleControl
// => eport GPO pins first

public class VehicleControl extends Thread {

	static long frequ = 50;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] initArguments = { "809", "827" };
		Rx.main(initArguments); // last action hewre is to start the thread receiveing from vehicle
		Tx.main(initArguments); // sends data to RemoteControl. like latest frame received etc

		// after this is done we start the thread that interprets the received commands
		// and controls the hardware of the rasperry pi
		VehicleControl thread = new VehicleControl();
		thread.start();

	}

	static byte[] engines() {
		/*
		 * returns 2 bytes for the 2 engines. byte[0] = left engine byte[1] = right
		 * engine value - 100 equals max signal in direction-1 value 0 equals no power
		 * to engine value 100 equals max signal in direction +1
		 */

		// fetch data from Rx to use them here. 0 indicates raw values
		byte a0 = Rx.provideAcceleration();
		byte s0 = Rx.provideSteering();
		byte z0 = Rx.provideZeroAngle();

		// calculate net-acceleration
		int a1 = z0 - a0;

		// angleX der vom smartphone kommt, stimmt nicht wirklich!!!!!!!!!!!!1
		// !!!!!!!!!!!!!!!!!!!!!!

		// provide output values of function
		byte[] bytes = new byte[2];
		bytes[0] = 10; // Erster Byte-Wert
		bytes[1] = 20; // Zweiter Byte-Wert

		// check output values for plausibility
		if (bytes[0] < -100) {
			bytes[0] = -100;
		}

		if (bytes[0] > 100) {
			bytes[0] = 100;
		}
		if (bytes[1] < -100) {
			bytes[1] = -100;
		}

		if (bytes[1] > 100) {
			bytes[1] = 100;
		}

		return bytes;

	}

	public void run() {
		try {

			// NEXT STEPS: jedes commando im detail durchgehen und versthen, was es tut. KI
			// dazu fragen

			 // Create GPIO controller
	        final GpioController gpio = GpioFactory.getInstance();

	        // Provision GPIO pin #18 as a PWM output pin
	        final GpioPinPwmOutput pwmPin = gpio.provisionPwmOutputPin(RaspiPin.GPIO_23);
			
			while (true) {

				// calculate new values to be set to GPIO Pins      

		        // Set the PWM frequency (optional)
		        pwmPin.setPwm(0); // Start with 0% duty cycle

		        // Gradually increase the PWM value
		        for (int i = 0; i <= 100; i++) {
		            pwmPin.setPwm(i); // Set PWM duty cycle (0-100)
		            try {
						Thread.sleep(20);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
		        }

		        // Gradually decrease the PWM value
		        for (int i = 100; i >= 0; i--) {
		            pwmPin.setPwm(i); // Set PWM duty cycle (0-100)
		            try {
						Thread.sleep(20);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
		        }

		        // Stop the PWM output
		        pwmPin.setPwm(0); // Set to 0% duty cycle
		        gpio.shutdown(); // Shutdown GPIO
				
				
				// HW related block for testing purposes
				/*
				// one proposed solution
				 System.out.println("<--Pi4J--> GPIO Control Example ... started.");
				 
			        // create gpio controller
			        final GpioController gpio = GpioFactory.getInstance();
			 
			        // provision gpio pin #01 as an output pin and turn on
			        final GpioPinDigitalOutput pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_04, "MyLED", PinState.HIGH);
			 
			        // set shutdown state for this pin
			        pin.setShutdownOptions(true, PinState.LOW);
			 
			        System.out.println("--> GPIO state should be: ON");
				try {
					Thread.sleep(1000); // Wait for 1 second
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				pin.toggle(); // Turn off the pin

				// Cleanup
				gpio.shutdown();
				//
				*/
				//HILFREICH für PWM ?
				// pin_gpio01.pulse(dauer, true);

				// sleep a bit, which is defined at the top of the module
				try {
					Thread.sleep(20);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		} finally {

		}
	}

}
