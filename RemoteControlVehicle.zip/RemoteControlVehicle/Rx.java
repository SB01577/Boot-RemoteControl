import java.net.*;
import java.io.*;

public class Rx extends Thread {
	static byte[] data = new byte[10]; //received data in known format
	static int time;	
	static InetAddress IPAddressRC; // address of sender
	static InetAddress IPAddressVehicle; // address of vehicle, i.e. this system here
	static byte latestFrame=-128; // saves the last framCounter transmitted by Vehicle. init value is -128
	
	public static InetAddress provideRCAddress() {
		return IPAddressRC;
	}
	
	public static byte provideAcceleration() {
		// data(2) is probably wrong)
		return data[2];
	}
	public static byte provideSteering() {
		// data(2) is probably wrong)
		return data[3];
	}
	public static byte provideZeroAngle() {
		return data[8];
	}
	
	public void run() {
		System.out.println("in Rx.run");
		DatagramSocket socket = null;
		try {
			socket = new DatagramSocket(50000); // Receiver's port
			byte[] buffer = new byte[30]; //sufficient buffer size
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
			
			//System.out.println("vor der while schleife");
			while (true) {
				//System.out.println("pos 1");
				//System.out.println("Rx run: warten auf Datenempfang von RC. schau mal in Tx.run, ob da was gesendet wird");	
				socket.receive(packet);
				//System.out.println("pos 2");
					
				//System.out.println(packet);
				//write received data to string. later it should be written ot byte-array data[]
				System.out.println("Rx run: Daten empfangen");				
				System.arraycopy(packet.getData(), 0, data, 0, 10);
				interpretData();
				//System.out.println("while schleife durch");
				Thread.sleep(100);
			}
			
			
		} catch (SocketException e) {
			// handle exception
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			if (socket != null) {
				socket.close();
			}
		}
		
	}
	
	private static Boolean initLink() {
		// receiver of 3 way handshake
		System.out.println("Rx initLink 1");
		DatagramSocket socket = null;
		try {
			socket = new DatagramSocket(50000); // Receiver's port
			
			// receive incoming SNY-message
			byte[] buffer = new byte[10]; //sufficient buffer size
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
			//System.out.println("init link start");
			System.out.println("Rx initLink 2");
			socket.receive(packet);
			System.out.println("Rx initLink 3");
			
			 // check for SYN
			byte[] empfang = packet.getData(); //packet is cast to byte-array
			System.out.println("Rx initLink 4");
			String bla = new String(empfang, 0, packet.getLength()); // then to string
			System.out.println("Rx initLink 5");
			if (bla.equals("SYN")) {
				// if it was a SYN then remember the RC's IP address
				IPAddressRC = packet.getAddress();
				//System.out.println("SYN received. IPAddressRC= "+IPAddressRC);
				System.out.println("Rx initLink 6");
				
				// send SYN-ACK to sender 
				String antwort = "SYN-ACK"; // dont change this string. sender is waiting for that string
				byte[] antwortByte = antwort.getBytes(); // kopiert den string in ein byte-array
				System.out.println("Rx initLink 7");
				DatagramPacket packet2 = new DatagramPacket(antwortByte, antwortByte.length, IPAddressRC, 50000);
				
				/*try {
				Thread.sleep(199);
				} catch (InterruptedException e) {
					
				}
				*/
				
				socket.send(packet2);
				System.out.println("Rx initLink 8");
				//System.out.println("SYN-ACK to sender ");
				
				// wait for ACK
				byte[] byteACK = new byte[10]; //sufficient buffer size
				DatagramPacket packet3 = new DatagramPacket(byteACK, byteACK.length);
				System.out.println("Rx initLink 9");
				socket.receive(packet3);
				//check for ACK-content
				System.out.println("Rx initLink 10");
				
				byte[] empfang2 = packet3.getData(); //packet is cast to byte-array
				String bla2 = new String(empfang2, 0, packet3.getLength()); // then to string
				System.out.println("Rx initLink 11");
				if (bla2.equals("ACK")) {
					return true;
				}
				else {
					return false;
				}
			}
			else {
				//if it was not a 3 way handshake throw some error
				System.out.println("Vehicle Rx initLink: message received but it was not a SYN");
				return false;
			}
		
			
			
			
		} catch (SocketException e) {
			// handle exception
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}  finally {
			if (socket != null) {
				socket.close();
			}
		}
		return false;
		
	}
	
	
	public static void main(String[] args) {
		// init link to sender
		if (initLink()) {
			System.out.println("Rx linkInit successfull");
			// init thread
			time = Integer.parseInt(args[1]);
			Rx thread = new Rx();
			thread.start();
		}
		else {
			System.out.println("Rx linkInit has failed");
		}
			
	}
	
	static void interpretData() {
		//data 0
		System.out.print(data[0]);
		
		//data 1
		System.out.print(data[1]);
		
		//data 2
		System.out.print(data[2]);

		//data 3
		System.out.print(data[3]);

		//data 4
		System.out.print(data[4]);

		//data 5
		System.out.print(data[5]);
		
		//data 6
		System.out.print(data[6]);

		//data 7 
		// receive FrameCOunter from Vehicle
		latestFrame = data[7];
		System.out.print(data[7]);

		//data 8 zero angle at which engine is neither accelerated nor braked
		System.out.print(data[8]);

		//data 9
		System.out.print(data[9]);
		
		System.out.println("frameCounter is: "+data[7]);
	}
	public static byte getLatestFrame() {
		return latestFrame;
	}

}
